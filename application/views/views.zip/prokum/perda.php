
<!-- Peraturan Terbaru -->
<section class="middle">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<div class="sec_title position-relative text-center mb-5">
					<h6 class="text-muted mb-0">
						Daftar <?=$subtitle?> yang terbaru
					</h6>
					<h3 class="ft-bold">
						<span style="text-transform: uppercase;"><?=$subtitle?></span> TERBARU
					</h3>
				</div>
			</div>
		</div>
		<div class="row align-items-center"> 
			<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
				<div class="job_grid d-block border rounded">
					<a href="https://jdih.sukoharjokab.go.id/produk/detail/11759">
					</a><div class="cats-box mlb-res rounded bg-white d-flex align-items-center justify-content-start px-3 py-3"><a href="https://jdih.sukoharjokab.go.id/produk/detail/11759">
						<div class="jb-list01-thumb">
							<img src="<?=site_url('./assets/v3/')?>riset-dan-inovasi-daerah-2024-blugo.png" class="img-fluid-barcode" width="80" alt="">
						</div>
					</a><div class="jb-list01 pl-3"><a href="https://jdih.sukoharjokab.go.id/produk/detail/11759">
						<div class="jb-list-01-title">
							<h6 class="ft-medium mb-1">
							Riset dan Inovasi Daerah                                        </h6>
						</div>
						<div class="jb-list-01-info d-block mb-3">
							<span class="text-muted mr-2">
								<i class="lni lni-check-box mr-1"></i>
							Peraturan Daerah Nomor 8 Tahun 2024                                        </span>
						</div>
					</a><div class="jb-list-01-title d-inline"><a href="https://jdih.sukoharjokab.go.id/produk/detail/11759">
						<span class="mr-2 mb-2 d-inline-flex px-2 py-1 rounded text-info bg-light-info">
						Peraturan Daerah                                        </span>
						<span class="px-2 mb-2 d-inline-flex py-1 rounded text-purple bg-light-purple">
						Infrastruktur                                        </span>
					</a><a href="https://sukodrive.sukoharjokab.go.id/index.php/s/mMGj5dqGogBRjWE" target="_blank">
						<span class="px-2 mb-2 d-inline-flex py-1 rounded text-warning bg-light-warning">
							Lihat
						</span>
					</a>
					<a href="https://sukodrive.sukoharjokab.go.id/index.php/s/mMGj5dqGogBRjWE/download" target="_blank">
						<span class="px-2 mb-2 d-inline-flex py-1 rounded text-danger bg-light-danger">
							Unduh
						</span>
					</a>
				</div>
			</div>
		</div> 
	</div>
</div>  
</div>
<div class="row justify-content-center">
	<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
		<div class="position-relative text-center">
			<a href="https://jdih.sukoharjokab.go.id/produk" class="btn btn-md theme-bg rounded text-light hover-theme">
				Produk Hukum Lainya...
				<i class="fa fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
</div>
</div>
</section>